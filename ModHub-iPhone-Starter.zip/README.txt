MODHUB IPHONE STARTER

This is a working web-app prototype inspired by the general app-catalogue layout of HappyMod.
The uploaded APK was inspected: its bundled HTML/JavaScript assets include a HappyMod native
ad-bridge demo (banner/fullscreen/reward ad calls), but do not provide a readable app catalogue
or enough source to reproduce the original service exactly. This starter therefore uses clearly
labelled demo listings.

TO PUT IT ON YOUR IPHONE 17:
1. Host this folder on an HTTPS website (for example, a GitHub Pages site).
2. Open the HTTPS address in Safari on your iPhone.
3. Tap Share, then Add to Home Screen, then Add.
4. Launch it from the new Home Screen icon.

IMPORTANT:
- iOS cannot install or run the uploaded Android APK.
- This web app does not download, modify, or install APK/IPA files.
- Replace demo entries with verified, lawful app listings and official iOS/App Store links before public use.
